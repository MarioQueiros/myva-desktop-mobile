package com.pt.myva_mobile;

import com.google.ads.*;
import com.google.ads.AdRequest.ErrorCode;

class MyClass implements com.google.ads.AdListener {
	public void onReceiveAd(Ad ad) {
	}

	public void onFailedToReceiveAd(Ad ad, ErrorCode error) {
	}

	public void onPresentScreen(Ad ad) {
	}

	public void onDismissScreen(Ad ad) {
	}

	public void onLeaveApplication(Ad ad) {
	}
}