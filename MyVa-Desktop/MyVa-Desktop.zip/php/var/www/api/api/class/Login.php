<?php

include_once 'Credentials_DB.php';
include_once 'Utils.php';
include_once 'passwordLib.php';

function login($app)
{
    $request = (array) json_decode($app->request()->getBody());
    $username = $request['username'];
    $password = $request['password'];

    try
    {
        $credentials = new Credentials_DB();
        $pdo = new PDO($credentials->getDSN(), $credentials->getUSER(), $credentials->getPASSWORD());
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch (PDOException $ex)
    {
        die(json_encode(array('message' => 'Unable to connect')));
    }

    $stmt = $pdo->prepare('SELECT Password,RegConf FROM Users WHERE Username=:user');
    $stmt->bindParam(':user', $username);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $pass = $row['Password'];
    $reg = $row['RegConf'];
    
    if ($stmt->rowCount() != 0)
    {
        if ($reg == 1)
        {
            $pass_gen = password_verify($password, $pass);

            if ($pass == $pass_gen)
            {
                $stmt = $pdo->prepare('SELECT PubKey_ID FROM Users WHERE Username=:user');
                $stmt->bindParam(':user', $username);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);

                $stmt = $pdo->prepare('SELECT PubKey FROM PubKey WHERE ID=:id');
                $stmt->bindParam(':id', $row['PubKey_ID']);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);

                $p = $row['PubKey'];
                $app->response()->header('Content-Type', 'application/json');
                $app->response()->header('X-Status-Reason', json_encode(array('PubKey' => $p)));
                echo json_encode(array('PubKey' => $p));
            } else
            {
                $app->response()->status(401);
                $app->response()->header('X-Status-Reason', json_encode(array('Error' => 'Password incorrect')));
            }
        } else
        {
            $app->response()->status(401);
            $app->response()->header('X-Status-Reason', json_encode(array('Error' => 'Please Confirm the account before you login.')));
        }
    } else
    {
        $app->response()->status(401);
        $app->response()->header('X-Status-Reason', json_encode(array('Error' => 'User not registered.')));
    }
}
